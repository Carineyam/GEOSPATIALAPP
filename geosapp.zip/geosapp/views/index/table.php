<h2>Liste des Éléments</h2>
<form action="index.php" method="POST" class="d-flex justify-content-end mb-3">
    <button type="submit" name="sort" value="asc" class="btn btn-link">Trier par Nom (Asc)</button>
    <button type="submit" name="sort" value="desc" class="btn btn-link">Trier par Nom (Desc)</button>
</form>
<table class="table">
    <thead>
        <tr><th>Nom</th><th>Type</th><th>Latitude (Centroïde)</th><th>Longitude (Centroïde)</th><th>Actions</th></tr>
    </thead>
    <tbody>
        <?php foreach ($lieux as $lieu): ?>
            <tr data-type="<?= $lieu['type_geometrie'] ?>">
                <td><?= htmlspecialchars($lieu['nom']) ?></td>
                <td><?= str_replace('ST_', '', $lieu['type_geometrie']) ?></td>
                <td><?= htmlspecialchars($lieu['lat']) ?></td>
                <td><?= htmlspecialchars($lieu['lon']) ?></td>
                <td>
                    <?php if ($lieu['type_geometrie'] === 'ST_Point'): ?>
                        <a href="edit.php?id=<?= $lieu['id'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                    <?php endif; ?>
                    <a href="delete.php?id=<?= $lieu['id'] ?>" onclick="return confirm('Êtes-vous sûr ?');" class="btn btn-danger btn-sm">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>