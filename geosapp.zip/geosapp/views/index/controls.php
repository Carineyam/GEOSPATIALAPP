<h2>Contrôles</h2>
<div class="mb-3">
   <label class="form-label">Filtrer par type :</label>
    <div class="form-check form-check-inline">
        <input class="form-check-input filter-type" type="checkbox" id="filter-point" value="ST_Point">
        <label class="form-check-label" for="filter-point">Points</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input filter-type" type="checkbox" id="filter-line" value="ST_LineString">
        <label class="form-check-label" for="filter-line">Lignes</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input filter-type" type="checkbox" id="filter-polygon" value="ST_Polygon">
        <label class="form-check-label" for="filter-polygon">Polygones</label>
    </div>
</div>
<label for="location-select" class="form-label">Choisissez un élément :</label>
<select id="location-select" class="form-select mb-3">
    <option value="" disabled selected>-- Sélectionnez un lieu --</option>
    <?php foreach ($lieux as $lieu): ?>
        <option value="<?= $lieu['id'] ?>" data-lat="<?= $lieu['lat'] ?>" data-lon="<?= $lieu['lon'] ?>" data-type="<?= $lieu['type_geometrie'] ?>">
            <?= htmlspecialchars($lieu['nom']) ?> (<?= str_replace('ST_', '', $lieu['type_geometrie']) ?>)
        </option>
    <?php endforeach; ?>
</select>
<button id="reset-map" class="btn btn-secondary w-100">Réinitialiser la carte</button>

<h4 class="mt-4">Liste des géométries</h4>
<table class="table table-bordered" id="geometry-table">
    
            <thead>
    <tr>
        <th data-sort="nom" style="cursor: pointer;">Nom ▲▼</th>
        <th data-sort="type" style="cursor: pointer;">Type ▲▼</th>
    </tr>
</thead>
       
    <tbody>
        <!-- Les lignes seront insérées dynamiquement -->
    </tbody>
</table>