<h2 class="mt-4">Ajouter un Nouveau Point</h2>
<form action="manage.php" method="POST" class="mb-4">
    <input type="hidden" name="type_geometrie" value="ST_Point">
    <div class="mb-3">
        <label for="nom" class="form-label">Nom :</label>
        <input type="text" id="nom" name="nom" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="latitude" class="form-label">Latitude :</label>
        <input type="text" id="latitude" name="latitude" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="longitude" class="form-label">Longitude :</label>
        <input type="text" id="longitude" name="longitude" class="form-control" required>
    </div>
    <button type="submit" class="btn btn-primary">Ajouter</button>
</form>