
var osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
});

var arcgisLayer = L.tileLayer('https://server.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
    attribution: 'Tiles © Esri'
});

var bingLayer = L.tileLayer('https://ecn.t3.tiles.virtualearth.net/tiles/a{q}.jpeg?g=1', {
    attribution: '© Microsoft Bing Maps',
    subdomains: ['t0', 't1', 't2', 't3'],
    tms: false
})

// Initialisation de la carte


var map = L.map('map', {
    center: [12.3710, -1.5195],
    zoom: 13,
    layers: [osmLayer]  // couche de fond par défaut
});
// 🔧 Activation des outils d'édition
map.editTools = new L.Editable(map);


var baseMaps = {
    "OpenStreetMap": osmLayer,
    "Esri World Imagery": arcgisLayer,
    "Bing Maps": bingLayer
};

L.control.layers(baseMaps, null, { collapsed: false }).addTo(map)


// Création des couches pour chaque type de géométrie
var pointLayer = L.layerGroup().addTo(map);
var lineLayer = L.layerGroup().addTo(map);
var polygonLayer = L.layerGroup().addTo(map);

// Style pour les différentes géométries
var pointStyle = {
    radius: 8,
    fillColor: "#ff7800",
    color: "#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.8
};

var lineStyle = {
    color: "#3388ff",
    weight: 4,
    opacity: 1
};

var polygonStyle = {
    fillColor: "#33cc33",
    color: "#006600",
    weight: 2,
    opacity: 1,
    fillOpacity: 0.5
};
var orangeIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    iconSize:     [25, 41],
    iconAnchor:   [12, 41],
    popupAnchor:  [1, -34],
    shadowSize:   [41, 41]
});

// Ajout des éléments à la carte
var lieux = window.lieuxData || [];
var markers = {};

lieux.forEach(lieu => {
    var geometry = JSON.parse(lieu.geojson);
    var layer;

    switch (lieu.type_geometrie) {
        case 'ST_Point':
            layer = L.marker([lieu.lat, lieu.lon], {
                icon: orangeIcon,
                draggable: false
            }).bindPopup(`<b>${lieu.nom}</b><br>Type: Point`);

            layer.on('dragend', function (e) {
                var newLatLng = e.target.getLatLng();
                lieu.lat = newLatLng.lat;
                lieu.lon = newLatLng.lng;
                console.log(`Nouvelles coordonnées pour ${lieu.nom}: ${lieu.lat}, ${lieu.lon}`);
            });

            pointLayer.addLayer(layer);
            break;

        case 'ST_LineString':
            const lineCoords = geometry.coordinates.map(coord => [coord[1], coord[0]]);
            layer = L.polyline(lineCoords, {
                ...lineStyle
            }).bindPopup(`<b>${lieu.nom}</b><br>Type: Ligne`);

            lineLayer.addLayer(layer);
            break;

        case 'ST_Polygon':
            const polygonCoords = geometry.coordinates[0].map(coord => [coord[1], coord[0]]);
            layer = L.polygon(polygonCoords, {
                ...polygonStyle
            }).bindPopup(`<b>${lieu.nom}</b><br>Type: Polygone`);

            polygonLayer.addLayer(layer);
            break;
    }

    markers[lieu.id] = layer;
});

// Légende
var legend = L.control({position: 'bottomright'});
legend.onAdd = function(map) {
    var div = L.DomUtil.create('div', 'legend');
    div.innerHTML = `
        <h6>Légende</h6>
        <div><img src="https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png" 
             style="width:15px;height:25px;vertical-align:middle;"> Points</div>
        <div><i style="background: ${lineStyle.color}; width: 15px; height: 15px; display: inline-block;"></i> Lignes</div>
        <div><i style="background: ${polygonStyle.fillColor}; width: 15px; height: 15px; display: inline-block;"></i> Polygones</div>
    `;
    return div;
};
legend.addTo(map);

 // Gestion des filtres
document.querySelectorAll('.filter-type').forEach(checkbox => {
    checkbox.addEventListener('change', function () {
        // Vérifier quelles cases sont cochées
        const pointChecked = document.getElementById('filter-point').checked;
        const lineChecked = document.getElementById('filter-line').checked;
        const polygonChecked = document.getElementById('filter-polygon').checked;

        // Si aucune case cochée, afficher toutes les couches
        if (!pointChecked && !lineChecked && !polygonChecked) {
            pointLayer.addTo(map);
            lineLayer.addTo(map);
            polygonLayer.addTo(map);
        } else {
            // Afficher uniquement les couches sélectionnées
            pointChecked ? pointLayer.addTo(map) : pointLayer.remove();
            lineChecked ? lineLayer.addTo(map) : lineLayer.remove();
            polygonChecked ? polygonLayer.addTo(map) : polygonLayer.remove();
        }
    });
});


 // Fonction pour afficher les lieux filtrés dans le tableau
    function updateGeometryTable() {
        const tableBody = document.querySelector('#geometry-table tbody');
        tableBody.innerHTML = ''; // vider les lignes

        const checkedTypes = Array.from(document.querySelectorAll('.filter-type:checked'))
            .map(cb => cb.value);

        const lieuxFiltres = checkedTypes.length > 0
            ? lieux.filter(lieu => checkedTypes.includes(lieu.type_geometrie))
            : lieux;

        lieuxFiltres.forEach(lieu => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${lieu.nom}</td>
                <td>${lieu.type_geometrie.replace('ST_', '')}</td>
            `;
            tableBody.appendChild(row);
        });
    }

    // Attacher l’événement aux checkboxes
    document.querySelectorAll('.filter-type').forEach(checkbox => {
        checkbox.addEventListener('change', updateGeometryTable);
    });

    // Appeler une première fois pour remplir le tableau au chargement
    document.addEventListener('DOMContentLoaded', updateGeometryTable);


let lieuxFiltres = [...lieux]; // stocke les lieux filtrés
    let currentSort = { key: null, asc: true }; // état de tri

    function updateGeometryTable() {
        const tableBody = document.querySelector('#geometry-table tbody');
        tableBody.innerHTML = '';

        const checkedTypes = Array.from(document.querySelectorAll('.filter-type:checked'))
            .map(cb => cb.value);

        lieuxFiltres = checkedTypes.length > 0
            ? lieux.filter(lieu => checkedTypes.includes(lieu.type_geometrie))
            : [...lieux];

        applySorting();
    }

    function applySorting() {
    const tableBody = document.querySelector('#geometry-table tbody');
    tableBody.innerHTML = '';

    let sorted = [...lieuxFiltres];

    if (currentSort.key) {
        sorted.sort((a, b) => {
            let valA = a[currentSort.key].toLowerCase();
            let valB = b[currentSort.key].toLowerCase();

            if (valA < valB) return currentSort.asc ? -1 : 1;
            if (valA > valB) return currentSort.asc ? 1 : -1;
            return 0;
        });
    }

    sorted.forEach(lieu => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${lieu.nom}</td>
            <td>${lieu.type_geometrie.replace('ST_', '')}</td>
        `;
        row.style.cursor = 'pointer'; // Optionnel : curseur pointeur

        row.addEventListener('click', () => {
            zoomToLieu(lieu);
        });

        tableBody.appendChild(row);
    });
}

function zoomToLieu(lieu) {
    const layer = markers[lieu.id];

    if (layer) {
        // Récupérer les bounds pour les lignes et polygones
        if (layer.getBounds) {
            map.fitBounds(layer.getBounds());
        } 
        // Pour les points (markers)
        else if (layer.getLatLng) {
            map.setView(layer.getLatLng(), 16);
        }

        // Affiche le popup lié à cette couche
        layer.openPopup();
    } else {
        console.warn(`Aucun layer trouvé pour le lieu avec id ${lieu.id}`);
    }
}
    // Attacher les événements de tri aux en-têtes
    document.querySelectorAll('#geometry-table th').forEach(th => {
        th.addEventListener('click', () => {
            const key = th.dataset.sort === 'type' ? 'type_geometrie' : 'nom';
            if (currentSort.key === key) {
                currentSort.asc = !currentSort.asc;
            } else {
                currentSort.key = key;
                currentSort.asc = true;
            }
            applySorting();
        });
    });

    // Attacher les événements de filtre
    document.querySelectorAll('.filter-type').forEach(cb => {
        cb.addEventListener('change', updateGeometryTable);
    });

    document.addEventListener('DOMContentLoaded', updateGeometryTable);
// Ajoutez cette fonction pour sauvegarder les styles originaux
function saveOriginalStyles() {
    [pointLayer, lineLayer, polygonLayer].forEach(layer => {
        layer.eachLayer(function(feature) {
            if (!feature._originalStyle) {
                if (feature instanceof L.Marker) {
                    feature._originalStyle = { icon: feature.options.icon };
                } else {
                    feature._originalStyle = {
                        color: feature.options.color,
                        fillColor: feature.options.fillColor,
                        weight: feature.options.weight
                    };
                }
            }
        });
    });
}

// Appelez cette fonction après le chargement des données
saveOriginalStyles();

// Modifiez la fonction highlightFeature
function highlightFeature(marker, highlight) {
    if (highlight) {
        marker.setIcon(L.icon({
            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
            shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        }));
    } else {
        marker.setIcon(orangeIcon);
    }
}
// Gestion de la sélection dans le menu déroulant
document.getElementById('location-select').addEventListener('change', function() {
    var selectedOption = this.options[this.selectedIndex];
    var lat = selectedOption.getAttribute('data-lat');
    var lon = selectedOption.getAttribute('data-lon');
    var type = selectedOption.getAttribute('data-type');
    
    if (lat && lon) {
        map.setView([lat, lon], 15);
        
        // Surligner l'élément sélectionné
        var id = selectedOption.value;
        if (markers[id]) {
            if (type === 'ST_Point') {
                markers[id].setStyle({color: '#ff0000', fillColor: '#ff0000'});
                setTimeout(() => {
                    markers[id].setStyle(pointStyle);
                }, 2000);
            } else if (type === 'ST_LineString') {
                markers[id].setStyle({color: '#ff0000'});
                setTimeout(() => {
                    markers[id].setStyle(lineStyle);
                }, 2000);
            } else if (type === 'ST_Polygon') {
                markers[id].setStyle({color: '#ff0000', fillColor: '#ff0000'});
                setTimeout(() => {
                    markers[id].setStyle(polygonStyle);
                }, 2000);
            }
            markers[id].openPopup();
        }
    }
});


// Réinitialisation de la carte
document.getElementById('reset-map').addEventListener('click', function() {
    map.setView([12.3710, -1.5195], 13);
    document.getElementById('location-select').selectedIndex = 0;
    
    Object.values(markers).forEach(marker => {
        if (marker instanceof L.CircleMarker) {
            marker.setStyle(pointStyle);
        } else if (marker instanceof L.Polyline) {
            marker.setStyle(lineStyle);
        } else if (marker instanceof L.Polygon) {
            marker.setStyle(polygonStyle);
        }
    });
});


// Filtrage du tableau
document.querySelectorAll('.filter-type').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        var type = this.value.replace('ST_', '');
        var rows = document.querySelectorAll('tbody tr');
        
        rows.forEach(row => {
            var rowType = row.getAttribute('data-type');
            if (this.checked) {
                if (rowType === this.value) {
                    row.style.display = '';
                }
            } else {
                if (rowType === this.value) {
                    row.style.display = 'none';
                }
            }
        });
    });
});
// (Le code précédent reste inchangé jusqu'à la partie des marqueurs)

// Ajout des éléments à la carte

// Après la création des marqueurs...

// Variables globales
var selectedFeatureId = null;
var originalPositions = {};

// Initialiser le panneau de contrôle
function initFeatureControls() {
    const featureSelect = document.getElementById('feature-select');

    // Vider et remplir le select
    featureSelect.innerHTML = '<option value="">-- Choisir un élément --</option>';

    lieux.forEach(lieu => {
        const option = document.createElement('option');
        option.value = lieu.id;
        option.textContent = lieu.nom;

        if (lieu.type_geometrie === 'ST_Point') {
            option.dataset.lat = lieu.lat;
            option.dataset.lon = lieu.lon;

            originalPositions[lieu.id] = {
                lat: lieu.lat,
                lon: lieu.lon,
                nom: lieu.nom
            };
        }

        featureSelect.appendChild(option);
    });

    // Gestion du changement de sélection
   featureSelect.addEventListener('change', function () {
    const featureId = this.value;
    selectedFeatureId = featureId;

    const coordsContainer = document.getElementById('point-coords-container');
    const nameInput = document.getElementById('feature-name');
    const saveBtn = document.getElementById('save-feature-btn');
    const editBtn = document.getElementById('edit-geometry-btn');

    // Réinitialiser tous les marqueurs
    Object.entries(markers).forEach(([id, marker]) => {
        if (marker.dragging) {
            marker.dragging.disable();
            highlightFeature(marker, false);
            marker.off('dragend', updateFeatureCoords);
        }
    });

    // Réinitialiser les éléments
    coordsContainer.style.display = 'none';
    editBtn.style.display = 'none';
    saveBtn.style.display = 'none';
    nameInput.disabled = true;

    if (featureId) {
        const lieu = lieux.find(l => l.id == featureId);
        if (!lieu) return;

        const isPoint = lieu.type_geometrie === 'ST_Point';
        const isLine = lieu.type_geometrie === 'ST_LineString';
        const isPolygon = lieu.type_geometrie === 'ST_Polygon';

        nameInput.disabled = false;
        nameInput.value = lieu.nom;

        if (isPoint) {
            // Activer et afficher le bouton "Enregistrer"
            saveBtn.disabled = false;
            saveBtn.style.display = 'inline-block';

            coordsContainer.style.display = 'block';
            document.getElementById('point-coords').textContent =
                `Lat: ${parseFloat(lieu.lat).toFixed(6)}, Lng: ${parseFloat(lieu.lon).toFixed(6)}`;

            map.setView([lieu.lat, lieu.lon], 15);
            highlightFeature(markers[featureId], true);

            if (markers[featureId] && markers[featureId].dragging) {
                markers[featureId].dragging.enable();
                markers[featureId].on('dragend', updateFeatureCoords);
            }
        }

        if (isLine || isPolygon) {
            editBtn.style.display = 'inline-block';
            const layer = markers[featureId];

            if (layer && typeof layer.getBounds === 'function') {
                map.fitBounds(layer.getBounds());
            }

            highlightFeature(layer, true);

            // Bouton "Modifier" active l'édition
            document.addEventListener('click', function handler(e) {
                if (e.target && e.target.id === 'edit-geometry-btn') {
                    console.log("🛠️ Bouton 'Modifier' cliqué !");
                    enableGeometryEditing(layer);
                    document.removeEventListener('click', handler); // évite les doublons
                }
            });
        }

    } else {
        resetFeatureControls();
    }
});


function enableGeometryEditing(layer) {
    if (!layer) return;

    const editBtn = document.getElementById('edit-geometry-btn');
    
    if (layer.editEnabled && layer.editEnabled()) {
        // Si déjà en mode édition, terminer l'édition
        layer.disableEdit();
        editBtn.textContent = 'Modifier';
        saveGeometryChanges(layer); // Enregistrer les modifications
    } else {
        // Activer le mode édition
        if (layer.enableEdit) {
            layer.enableEdit();
            editBtn.textContent = 'Terminer la modification';
            
            // Centrer la carte sur la géométrie
            if (typeof layer.getBounds === 'function') {
                map.fitBounds(layer.getBounds().pad(0.5));
            }
            
            alert("Mode édition activé. Modifiez la forme puis cliquez sur 'Terminer la modification' pour enregistrer.");
        } else {
            console.warn("Ce layer ne supporte pas l'édition.");
        }
    }
}
function saveGeometryChanges(layer) {
    if (!selectedFeatureId) return;
    
    const lieu = lieux.find(l => l.id == selectedFeatureId);
    if (!lieu) return;
    
    let geojson;
    
   if (layer instanceof L.Polygon) {
    // Polygone
    const coords = layer.getLatLngs()[0].map(ll => [ll.lng, ll.lat]);
    if (coords.length < 3) {
        showStatus('Un polygone doit avoir au moins 3 points.', 'error');
        return;
    }
    coords.push(coords[0]); // fermer le polygone
    geojson = {
        type: "Polygon",
        coordinates: [coords]
    };
} else if (layer instanceof L.Polyline) {
    // Ligne
    const coords = layer.getLatLngs().map(ll => [ll.lng, ll.lat]);
    if (coords.length < 2) {
        showStatus('Une ligne doit avoir au moins 2 points.', 'error');
        return;
    }
    geojson = {
        type: "LineString",
        coordinates: coords
    };
}
    
    const newName = document.getElementById('feature-name').value.trim();
    
    showStatus('Enregistrement en cours...', 'loading');
    
    const formData = new FormData();
    formData.append('id', selectedFeatureId);
    formData.append('nom', newName);
    formData.append('geojson', JSON.stringify(geojson));
    
    fetch('update_geometry.php', {
        method: 'POST',
        body: formData,
        headers: {
            'Accept': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Mettre à jour les données locales
            lieu.nom = newName;
            lieu.geojson = JSON.stringify(geojson);
            
            // Mettre à jour le popup
            const type = lieu.type_geometrie.replace('ST_', '');
            layer.setPopupContent(`<b>${newName}</b><br>Type: ${type}`);
            
            showStatus('Modifications enregistrées!', 'success');
        } else {
            throw new Error(data.message || 'Erreur lors de l\'enregistrement');
        }
    })
    .catch(error => {
        console.error('Erreur:', error);
        showStatus(`Échec: ${error.message}`, 'error');
    });
}

 // Gestion du bouton modifier
 document.getElementById('edit-geometry-btn').addEventListener('click', function () {
    if (selectedFeatureId && markers[selectedFeatureId]) {
        enableGeometryEditing(markers[selectedFeatureId]);
    } else {
        console.warn("Aucun élément sélectionné pour l'édition.");
    }
});
    // Gestion du bouton enregistrer
    document.getElementById('save-feature-btn').addEventListener('click', saveFeatureChanges);

    // Mise à jour du popup si nom modifié
    document.getElementById('feature-name').addEventListener('input', function () {
        if (selectedFeatureId) {
            const lieu = lieux.find(l => l.id == selectedFeatureId);
            const type = lieu.type_geometrie.replace('ST_', '');
            markers[selectedFeatureId].setPopupContent(`<b>${this.value}</b><br>Type: ${type}`);
        }
    });
}

// Mise à jour des coordonnées
function updateFeatureCoords(e) {
    if (!selectedFeatureId) return;

    const newLatLng = e.target.getLatLng();
    document.getElementById('point-coords').textContent =
        `Lat: ${newLatLng.lat.toFixed(6)}, Lng: ${newLatLng.lng.toFixed(6)}`;
}



// Réinitialiser
function resetFeatureControls() {
    if (selectedFeatureId && markers[selectedFeatureId]) {
        if (markers[selectedFeatureId].dragging) {
            markers[selectedFeatureId].dragging.disable();
            markers[selectedFeatureId].off('dragend', updateFeatureCoords);
        }
        highlightFeature(markers[selectedFeatureId], false);
    }

    selectedFeatureId = null;
    document.getElementById('feature-name').value = '';
    document.getElementById('feature-name').disabled = true;
    document.getElementById('point-coords').textContent = 'Non sélectionné';
    document.getElementById('point-coords-container').style.display = 'none';
    document.getElementById('save-feature-btn').disabled = true;
    document.getElementById('save-status').textContent = '';
}

// Enregistrer les modifications
function saveFeatureChanges() {
    if (!selectedFeatureId) return;

    const marker = markers[selectedFeatureId];
    const lieu = lieux.find(l => l.id == selectedFeatureId);
    const isPoint = lieu.type_geometrie === 'ST_Point';
    const newName = document.getElementById('feature-name').value.trim();
    let lat = null, lon = null;

    if (isPoint) {
        const pos = marker.getLatLng();
        lat = pos.lat;
        lon = pos.lng;
        if (isNaN(lat) || isNaN(lon)) {
            showStatus('Coordonnées invalides', 'error');
            return;
        }
    }

    if (!newName || newName.length > 100) {
        showStatus('Nom invalide (1-100 caractères)', 'error');
        return;
    }

    showStatus('Enregistrement en cours...', 'loading');

    const formData = new FormData();
    formData.append('id', selectedFeatureId);
    formData.append('nom', newName);
    if (isPoint) {
        formData.append('lat', lat.toString());
        formData.append('lon', lon.toString());
    }

    fetch('update_point.php', {
        method: 'POST',
        body: formData,
        headers: {
            'Accept': 'application/json'
        }
    })
        .then(response => {
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Réponse non-JSON du serveur');
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                updateLocalData(selectedFeatureId, newName, lat, lon);
                showStatus('Enregistré avec succès!', 'success');
                setTimeout(resetFeatureControls, 2000);
            } else {
                throw new Error(data.message || 'Erreur inconnue');
            }
        })
        .catch(error => {
            console.error('Erreur:', error);
            showStatus(`Échec: ${error.message}`, 'error');
        });
}

// Statut
function showStatus(message, type) {
    const statusEl = document.getElementById('save-status');
    statusEl.innerHTML = type === 'loading'
        ? `<i class="fa fa-spinner fa-spin"></i> ${message}`
        : `<span class="text-${type === 'success' ? 'success' : 'danger'}">${message}</span>`;
}

// Mettre à jour les données locales
function updateLocalData(id, name, lat, lon) {
    const lieu = lieux.find(l => l.id == id);
    if (lieu) {
        lieu.nom = name;
        if (lat !== null && lon !== null) {
            lieu.lat = lat;
            lieu.lon = lon;
        }
    }

    const marker = markers[id];
    if (marker) {
        const type = lieu.type_geometrie.replace('ST_', '');
        marker.setPopupContent(`<b>${name}</b><br>Type: ${type}`);
    }

    const option = document.querySelector(`#feature-select option[value="${id}"]`);
    if (option) {
        option.textContent = name;
        if (lat !== null && lon !== null) {
            option.dataset.lat = lat;
            option.dataset.lon = lon;
        }
    }
}

// Initialisation
initFeatureControls();
// Ajouter un bouton dans votre interface HTML
document.getElementById('radius-select-btn').addEventListener('click', activateRadiusSelection);

// Variables pour gérer la sélection
var radiusSelectionActive = false;
var selectedCenterMarker = null;
var radiusCircle = null;
var radiusHighlightedFeatures = [];

// Activer/désactiver la sélection par rayon
function activateRadiusSelection() {
    radiusSelectionActive = !radiusSelectionActive;

    var btn = document.getElementById('radius-select-btn');
    var inputContainer = document.getElementById('radius-input-container');

    if (radiusSelectionActive) {
        btn.classList.add("active");
        map.on('click', onMapClickForRadiusSelection);
        inputContainer.style.display = "block"; // Montrer l'input
    } else {
        btn.classList.remove("active");
        map.off('click', onMapClickForRadiusSelection);
        inputContainer.style.display = "none";  // Cacher l'input
        resetRadiusSelection();
        lastClickLatLng = null; // reset du clic précédent
        document.getElementById("radius-input").value = ''; // effacer valeur
        document.getElementById("radius-result-list").style.display = "none";
    }
}
let lastClickLatLng = null;

function onMapClickForRadiusSelection(e) {
    if (!radiusSelectionActive) return;

    // Sauvegarde du centre cliqué
    lastClickLatLng = e.latlng;

    // Active l'affichage de l'input si non visible
    document.getElementById('radius-input-container').style.display = 'block';
}
document.getElementById("radius-validate-btn").addEventListener("click", function () {
    if (!lastClickLatLng) {
        alert("Cliquez d'abord sur la carte pour choisir le centre.");
        return;
    }

    const radiusInput = document.getElementById("radius-input");
    const radius = parseFloat(radiusInput.value);

    if (isNaN(radius) || radius <= 0) {
        alert("Veuillez entrer un rayon valide.");
        return;
    }

    // Créer ou mettre à jour le marqueur central
    if (selectedCenterMarker) {
        selectedCenterMarker.setLatLng(lastClickLatLng);
    } else {
        selectedCenterMarker = L.circleMarker(lastClickLatLng, {
            radius: 8,
            color: '#ff0000',
            fillColor: '#ff0000',
            fillOpacity: 1
        }).addTo(map);
    }

    // Créer ou mettre à jour le cercle de sélection
    if (radiusCircle) {
        radiusCircle.setLatLng(lastClickLatLng).setRadius(radius);
    } else {
        radiusCircle = L.circle(lastClickLatLng, {
            radius: radius,
            color: '#ff0000',
            fillColor: '#ff0000',
            fillOpacity: 0.2
        }).addTo(map);
    }

    // Appliquer la sélection
    highlightFeaturesInRadius(lastClickLatLng, radius);
});
// Mettre en surbrillance les éléments dans le rayon
function highlightFeaturesInRadius(center, radius) {
    resetRadiusHighlightedFeatures();

    const namesInRadius = [];

    [pointLayer, lineLayer, polygonLayer].forEach(layer => {
        layer.eachLayer(function(feature) {
            if (isFeatureInRadius(feature, center, radius)) {
                highlightRadiusFeature(feature, true);
                radiusHighlightedFeatures.push(feature);

                // Extraire le nom depuis le contenu du popup
                if (feature.getPopup()) {
                    const content = feature.getPopup().getContent();
                    const match = content.match(/<b>(.*?)<\/b>/);
                    if (match && match[1]) {
                        namesInRadius.push(match[1]);
                    }
                }
            }
        });
    });

    const resultDiv = document.getElementById("radius-result-list");
    resultDiv.style.display = "block";

    if (namesInRadius.length > 0) {
        resultDiv.innerHTML = `<strong>Géométries trouvées :</strong><ul>` +
            namesInRadius.map(name => `<li>${name}</li>`).join('') + `</ul>`;
    } else {
        resultDiv.innerHTML = `<em>Aucune géométrie trouvée dans le rayon.</em>`;
    }
}


// Vérifier si un élément est dans le rayon
function isFeatureInRadius(feature, center, radius) {
    if (feature instanceof L.Marker || feature instanceof L.CircleMarker) {
        return center.distanceTo(feature.getLatLng()) <= radius;
    }

    if (feature instanceof L.Polygon || feature instanceof L.Polyline) {
        let latlngs = feature.getLatLngs();
        let allPoints = [];

        const isFlat = Array.isArray(latlngs) && latlngs.length > 0 && !Array.isArray(latlngs[0]);

        if (isFlat) {
            allPoints = latlngs;
        } else {
            latlngs.forEach(part => {
                if (Array.isArray(part)) {
                    part.forEach(p => allPoints.push(p));
                } else {
                    allPoints.push(part);
                }
            });
        }

        const inRadius = allPoints.some(latlng => center.distanceTo(latlng) <= radius);
        console.log("→ Test:", feature instanceof L.Polygon ? "Polygon" : "Polyline", "→ In radius?", inRadius);
        return inRadius;
    }

    return false;
}

// Mettre en surbrillance un élément pour la sélection par rayon
function highlightRadiusFeature(feature, highlight) {
    if (!feature._radiusOriginalStyle) {
        if (feature instanceof L.Marker && feature.options.icon) {
            feature._radiusOriginalStyle = { icon: feature.options.icon };
        } else if (feature.setStyle) {
            feature._radiusOriginalStyle = {
                color: feature.options.color || '#3388ff',
                fillColor: feature.options.fillColor || '#3388ff',
                weight: feature.options.weight || 3
            };
        }
    }

    if (feature instanceof L.Marker) {
        feature.setIcon(highlight ? 
            L.icon({
                iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
                shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
                iconSize: [25, 41],
                iconAnchor: [12, 41],
                popupAnchor: [1, -34],
                shadowSize: [41, 41]
            }) : 
            feature._radiusOriginalStyle.icon
        );
    } else if (feature instanceof L.Polygon) {
        feature.setStyle(highlight ? {
            color: '#ff0000',
            fillColor: '#ff0000'
        } : feature._radiusOriginalStyle);
    } else if (feature instanceof L.Polyline) {
        feature.setStyle(highlight ? {
            color: '#ff0000',
            weight: 6
        } : feature._radiusOriginalStyle);
    }
}


// Réinitialiser la sélection par rayon
function resetRadiusSelection() {
    if (selectedCenterMarker) {
        map.removeLayer(selectedCenterMarker);
        selectedCenterMarker = null;
    }
    
    if (radiusCircle) {
        map.removeLayer(radiusCircle);
        radiusCircle = null;
    }
    
    resetRadiusHighlightedFeatures();
}

// Réinitialiser les éléments surlignés par rayon
function resetRadiusHighlightedFeatures() {
    radiusHighlightedFeatures.forEach(feature => {
        highlightRadiusFeature(feature, false);
    });
    radiusHighlightedFeatures = [];
}

// Ajouter aussi un style CSS pour le bouton
var style = document.createElement('style');
style.innerHTML = `
#radius-select-btn {
    background-color: white;
    border: none;
    color: black;
    padding: 5px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
    border-radius: 4px;
}
#radius-select-btn.active {
    background-color: #4CAF50;
    color: white;
}
`;
document.head.appendChild(style);
