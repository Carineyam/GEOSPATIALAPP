// map-init.js
import { osmLayer, baseMaps, pointLayer, lineLayer, polygonLayer } from './layers.js';

export const map = L.map('map', {
    center: [12.3710, -1.5195],
    zoom: 13,
    layers: [osmLayer]  // couche de fond par défaut
});

// Activation des outils d'édition
map.editTools = new L.Editable(map);

// Ajout des contrôles de couches
L.control.layers(baseMaps, null, { collapsed: false }).addTo(map);

// Ajout des couches de géométries
pointLayer.addTo(map);
lineLayer.addTo(map);
polygonLayer.addTo(map);