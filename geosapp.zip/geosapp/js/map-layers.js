// Styles
var pointStyle = {
    radius: 8,
    fillColor: "#ff7800",
    color: "#000",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.8
};

var lineStyle = {
    color: "#3388ff",
    weight: 4,
    opacity: 1
};

var polygonStyle = {
    fillColor: "#33cc33",
    color: "#006600",
    weight: 2,
    opacity: 1,
    fillOpacity: 0.5
};

var orangeIcon = L.icon({
    iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    iconSize: [25, 41],
    iconAnchor: [12, 41],
    popupAnchor: [1, -34],
    shadowSize: [41, 41]
});

// Création des couches
var pointLayer = L.layerGroup().addTo(map);
var lineLayer = L.layerGroup().addTo(map);
var polygonLayer = L.layerGroup().addTo(map);
var markers = {};

// Ajout des éléments
function addLieuxToMap(lieux) {
    lieux.forEach(lieu => {
        var geometry = JSON.parse(lieu.geojson);
        var layer;

        switch (lieu.type_geometrie) {
            case 'ST_Point':
                layer = L.marker([lieu.lat, lieu.lon], {
                    icon: orangeIcon,
                    draggable: false
                }).bindPopup(`<b>${lieu.nom}</b><br>Type: Point`);
                pointLayer.addLayer(layer);
                break;

            case 'ST_LineString':
                const lineCoords = geometry.coordinates.map(coord => [coord[1], coord[0]]);
                layer = L.polyline(lineCoords, lineStyle)
                    .bindPopup(`<b>${lieu.nom}</b><br>Type: Ligne`);
                lineLayer.addLayer(layer);
                break;

            case 'ST_Polygon':
                const polygonCoords = geometry.coordinates[0].map(coord => [coord[1], coord[0]]);
                layer = L.polygon(polygonCoords, polygonStyle)
                    .bindPopup(`<b>${lieu.nom}</b><br>Type: Polygone`);
                polygonLayer.addLayer(layer);
                break;
        }

        markers[lieu.id] = layer;
    });
}