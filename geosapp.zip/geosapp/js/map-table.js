var lieuxFiltres = [...lieux];
var currentSort = { key: null, asc: true };

function setupTableSorting() {
    document.querySelectorAll('#geometry-table th').forEach(th => {
        th.addEventListener('click', () => {
            const key = th.dataset.sort === 'type' ? 'type_geometrie' : 'nom';
            if (currentSort.key === key) {
                currentSort.asc = !currentSort.asc;
            } else {
                currentSort.key = key;
                currentSort.asc = true;
            }
            applySorting();
        });
    });
}

function applySorting() {
    const tableBody = document.querySelector('#geometry-table tbody');
    tableBody.innerHTML = '';

    let sorted = [...lieuxFiltres];
    if (currentSort.key) {
        sorted.sort((a, b) => {
            let valA = a[currentSort.key].toLowerCase();
            let valB = b[currentSort.key].toLowerCase();
            if (valA < valB) return currentSort.asc ? -1 : 1;
            if (valA > valB) return currentSort.asc ? 1 : -1;
            return 0;
        });
    }

    sorted.forEach(lieu => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${lieu.nom}</td>
            <td>${lieu.type_geometrie.replace('ST_', '')}</td>
        `;
        row.addEventListener('click', () => zoomToLieu(lieu));
        tableBody.appendChild(row);
    });
}

function zoomToLieu(lieu) {
    const layer = markers[lieu.id];
    if (layer) {
        if (layer.getBounds) {
            map.fitBounds(layer.getBounds());
        } else if (layer.getLatLng) {
            map.setView(layer.getLatLng(), 16);
        }
        layer.openPopup();
    }
}