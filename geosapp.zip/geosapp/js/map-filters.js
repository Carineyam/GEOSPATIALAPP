// Filtrage des couches
function setupLayerFilters() {
    document.querySelectorAll('.filter-type').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const pointChecked = document.getElementById('filter-point').checked;
            const lineChecked = document.getElementById('filter-line').checked;
            const polygonChecked = document.getElementById('filter-polygon').checked;

            if (!pointChecked && !lineChecked && !polygonChecked) {
                pointLayer.addTo(map);
                lineLayer.addTo(map);
                polygonLayer.addTo(map);
            } else {
                pointChecked ? pointLayer.addTo(map) : pointLayer.remove();
                lineChecked ? lineLayer.addTo(map) : lineLayer.remove();
                polygonChecked ? polygonLayer.addTo(map) : polygonLayer.remove();
            }
        });
    });
}

// Filtrage du tableau
function setupTableFilters() {
    document.querySelectorAll('.filter-type').forEach(checkbox => {
        checkbox.addEventListener('change', updateGeometryTable);
    });
}

function updateGeometryTable() {
    const tableBody = document.querySelector('#geometry-table tbody');
    tableBody.innerHTML = '';

    const checkedTypes = Array.from(document.querySelectorAll('.filter-type:checked'))
        .map(cb => cb.value);

    const lieuxFiltres = checkedTypes.length > 0
        ? lieux.filter(lieu => checkedTypes.includes(lieu.type_geometrie))
        : lieux;

    lieuxFiltres.forEach(lieu => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${lieu.nom}</td>
            <td>${lieu.type_geometrie.replace('ST_', '')}</td>
        `;
        tableBody.appendChild(row);
    });
}