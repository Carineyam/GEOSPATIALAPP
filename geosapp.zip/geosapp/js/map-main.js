// Chargement des données
var lieux = window.lieuxData || [];

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    addLieuxToMap(lieux);
    setupLayerFilters();
    setupTableFilters();
    setupTableSorting();
    updateGeometryTable();
});