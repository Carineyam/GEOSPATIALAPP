// Légende
var legend = L.control({position: 'bottomright'});
legend.onAdd = function(map) {
    var div = L.DomUtil.create('div', 'legend');
    div.innerHTML = `
        <h6>Légende</h6>
        <div><img src="https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-orange.png" 
             style="width:15px;height:25px;vertical-align:middle;"> Points</div>
        <div><i style="background: ${lineStyle.color}; width: 15px; height: 15px; display: inline-block;"></i> Lignes</div>
        <div><i style="background: ${polygonStyle.fillColor}; width: 15px; height: 15px; display: inline-block;"></i> Polygones</div>
    `;
    return div;
};
legend.addTo(map);