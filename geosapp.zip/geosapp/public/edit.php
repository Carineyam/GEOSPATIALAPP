<?php
include('../includes/db.php'); // Connexion à la base de données

// Connexion à la base de données
$conn = connectDB();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Vérifier si un ID est passé dans l'URL
    if (!isset($_GET['id']) || empty($_GET['id'])) {
        die("Identifiant du lieu non spécifié.");
    }

    // Récupérer l'ID et échapper les caractères spéciaux
    $id = intval($_GET['id']);

    // Récupérer les informations du lieu depuis la base
    $query = "SELECT id, nom, ST_X(geom) AS lon, ST_Y(geom) AS lat FROM lieux WHERE id = $1";
    $result = pg_query_params($conn, $query, [$id]);

    if (!$result || pg_num_rows($result) === 0) {
        die("Lieu introuvable.");
    }

    // Extraire les informations
    $lieu = pg_fetch_assoc($result);

} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données envoyées via le formulaire
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $nom = isset($_POST['nom']) ? trim($_POST['nom']) : null;
    $latitude = isset($_POST['latitude']) ? trim($_POST['latitude']) : null;
    $longitude = isset($_POST['longitude']) ? trim($_POST['longitude']) : null;

    // Vérifier que tous les champs sont renseignés
    if (empty($id) || empty($nom) || empty($latitude) || empty($longitude)) {
        die("Tous les champs doivent être remplis.");
    }

    // Vérification des formats
    if (!is_numeric($latitude) || !is_numeric($longitude)) {
        die("La latitude et la longitude doivent être des nombres.");
    }

    // Préparer la requête de mise à jour
    $query = "UPDATE lieux SET nom = $1, geom = ST_SetSRID(ST_MakePoint($2, $3), 4326) WHERE id = $4";
    $result = pg_query_params($conn, $query, [$nom, $longitude, $latitude, $id]);

    if (!$result) {
        die("Erreur lors de la mise à jour : " . pg_last_error($conn));
    }

    // Rediriger vers la page principale après la mise à jour
    header("Location: index.php");
    exit();
}

// Fermer la connexion à la base
pg_close($conn);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modifier un Lieu</title>
    
    <!-- Ajouter Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include('../includes/header.php'); ?>

<div class="container mt-4">
    <h1>Modifier un Lieu</h1>
    <form action="edit.php" method="POST">
        <!-- ID caché pour identifier le lieu à modifier -->
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($lieu['id']); ?>">

        <div class="mb-3">
            <label for="nom" class="form-label">Nom :</label>
            <input type="text" id="nom" name="nom" class="form-control" value="<?php echo htmlspecialchars($lieu['nom']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="latitude" class="form-label">Latitude :</label>
            <input type="text" id="latitude" name="latitude" class="form-control" value="<?php echo htmlspecialchars($lieu['lat']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="longitude" class="form-label">Longitude :</label>
            <input type="text" id="longitude" name="longitude" class="form-control" value="<?php echo htmlspecialchars($lieu['lon']); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Enregistrer les Modifications</button>
        <a href="index.php" class="btn btn-secondary">Annuler</a>
    </form>
</div>

<!-- Ajouter Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
