<?php
include('../includes/db.php'); // Connexion à la base de données

// Connexion à la base de données
$conn = connectDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données du formulaire
    $nom = isset($_POST['nom']) ? trim($_POST['nom']) : null;
    $latitude = isset($_POST['latitude']) ? trim($_POST['latitude']) : null;
    $longitude = isset($_POST['longitude']) ? trim($_POST['longitude']) : null;

    // Vérifier que tous les champs sont renseignés
    if (empty($nom) || empty($latitude) || empty($longitude)) {
        die("Tous les champs doivent être remplis.");
    }

    // Vérification des formats (optionnel, mais recommandé)
    if (!is_numeric($latitude) || !is_numeric($longitude)) {
        die("La latitude et la longitude doivent être des nombres.");
    }

    // Préparer la requête d'insertion
    $query = "INSERT INTO lieux (nom, geom) VALUES ($1, ST_SetSRID(ST_MakePoint($2, $3), 4326))";

    // Exécuter la requête
    $result = pg_query_params($conn, $query, [$nom, $longitude, $latitude]);

    if (!$result) {
        die("Erreur lors de l'ajout du lieu : " . pg_last_error($conn));
    }

    // Rediriger vers la page d'accueil après l'ajout
    header("Location: index.php");
    exit();
} else {
    // Si la méthode n'est pas POST, afficher une erreur
    die("Méthode HTTP non autorisée.");
}

// Fermer la connexion à la base
pg_close($conn);
