<?php
include('../includes/db.php'); // Connexion à la base de données

// Vérification de l'ID du lieu
if (!isset($_GET['id'])) {
    die("ID du lieu manquant");
}

$id = $_GET['id'];

// Connexion à la base de données
$conn = connectDB();

// Supprimer le lieu
$query = "DELETE FROM lieux WHERE id = $id";
$result = pg_query($conn, $query);

if ($result) {
    // Si la suppression est réussie, rediriger l'administrateur vers la page des lieux
    header("Location: index.php");
    exit;
} else {
    // Afficher un message d'erreur si la suppression échoue
    echo "Erreur lors de la suppression du lieu: " . pg_last_error();
}

pg_close($conn);
?>
























