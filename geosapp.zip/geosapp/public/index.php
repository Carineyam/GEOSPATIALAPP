<?php
include('../includes/db.php'); // Connexion à la base de données
include('../includes/header.php');

// Connexion à la base de données
$conn = connectDB();

// Vérifier si le tri est défini, sinon définir un tri par défaut
$sort = $_POST['sort'] ?? 'asc';

// Requête pour récupérer les lieux avec tri et type de géométrie
$query = "SELECT id, nom, ST_GeometryType(geom) AS type_geometrie, 
          ST_X(ST_Centroid(geom)) AS lon, 
          ST_Y(ST_Centroid(geom)) AS lat,
          ST_AsGeoJSON(geom) AS geojson
          FROM lieux 
          ORDER BY nom $sort";
$result = pg_query($conn, $query) or die("Erreur lors de la requête : " . pg_last_error());

// Stocker les résultats dans un tableau
$lieux = pg_fetch_all($result) ?: [];
pg_close($conn);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carte des Lieux du Burkina Faso</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #map { width: 100%; height: 500px; }
        .form-check-label { margin-right: 15px; }
        .legend { background: white; padding: 10px; border-radius: 5px; }
        .legend i { width: 18px; height: 18px; float: left; margin-right: 8px; opacity: 0.7; }
    </style>
</head>
<body>
<div class="container mt-4">
    <h1>Carte des Lieux du Burkina Faso</h1>
    <div class="row">
        <div class="col-md-6"><div id="map" class="map-container"></div></div>
        <div class="col-md-6">
            <h2>Contrôles</h2>
            <div class="mb-3">
                <label class="form-label">Filtrer par type :</label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input filter-type" type="checkbox" id="filter-point" value="ST_Point">
                    <label class="form-check-label" for="filter-point">Points</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input filter-type" type="checkbox" id="filter-line" value="ST_LineString">
                    <label class="form-check-label" for="filter-line">Lignes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input filter-type" type="checkbox" id="filter-polygon" value="ST_Polygon">
                    <label class="form-check-label" for="filter-polygon">Polygones</label>
                </div>
            </div>
            <label for="location-select" class="form-label">Choisissez un élément :</label>
            <select id="location-select" class="form-select mb-3">
                <option value="" disabled selected>-- Sélectionnez un lieu --</option>
                <?php foreach ($lieux as $lieu): ?>
                    <option value="<?= $lieu['id'] ?>" data-lat="<?= $lieu['lat'] ?>" data-lon="<?= $lieu['lon'] ?>" data-type="<?= $lieu['type_geometrie'] ?>">
                        <?= htmlspecialchars($lieu['nom']) ?> (<?= str_replace('ST_', '', $lieu['type_geometrie']) ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <button id="reset-map" class="btn btn-secondary w-100">Réinitialiser la carte</button>
        </div>
    </div>
    
    <!-- Formulaire d'ajout seulement pour les points -->
    <h2 class="mt-4">Ajouter un Nouveau Point</h2>
    <form action="manage.php" method="POST" class="mb-4">
        <input type="hidden" name="type_geometrie" value="ST_Point">
        <div class="mb-3">
            <label for="nom" class="form-label">Nom :</label>
            <input type="text" id="nom" name="nom" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="latitude" class="form-label">Latitude :</label>
            <input type="text" id="latitude" name="latitude" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="longitude" class="form-label">Longitude :</label>
            <input type="text" id="longitude" name="longitude" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Ajouter</button>
    </form>
    
    <h2>Liste des Éléments</h2>
    <form action="index.php" method="POST" class="d-flex justify-content-end mb-3">
        <button type="submit" name="sort" value="asc" class="btn btn-link">Trier par Nom (Asc)</button>
        <button type="submit" name="sort" value="desc" class="btn btn-link">Trier par Nom (Desc)</button>
    </form>
    <table class="table">
        <thead>
            <tr><th>Nom</th><th>Type</th><th>Latitude (Centroïde)</th><th>Longitude (Centroïde)</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach ($lieux as $lieu): ?>
                <tr data-type="<?= $lieu['type_geometrie'] ?>">
                    <td><?= htmlspecialchars($lieu['nom']) ?></td>
                    <td><?= str_replace('ST_', '', $lieu['type_geometrie']) ?></td>
                    <td><?= htmlspecialchars($lieu['lat']) ?></td>
                    <td><?= htmlspecialchars($lieu['lon']) ?></td>
                    <td>
                        <?php if ($lieu['type_geometrie'] === 'ST_Point'): ?>
                            <a href="edit.php?id=<?= $lieu['id'] ?>" class="btn btn-warning btn-sm">Modifier</a>
                        <?php endif; ?>
                        <a href="delete.php?id=<?= $lieu['id'] ?>" onclick="return confirm('Êtes-vous sûr ?');" class="btn btn-danger btn-sm">Supprimer</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
    var map = L.map('map').setView([12.3710, -1.5195], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    // Création des couches pour chaque type de géométrie
    var pointLayer = L.layerGroup().addTo(map);
    var lineLayer = L.layerGroup().addTo(map);
    var polygonLayer = L.layerGroup().addTo(map);

    // Style pour les différentes géométries
    var pointStyle = {
        radius: 8,
        fillColor: "#ff7800",
        color: "#000",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    };

    var lineStyle = {
        color: "#3388ff",
        weight: 4,
        opacity: 1
    };

    var polygonStyle = {
        fillColor: "#33cc33",
        color: "#006600",
        weight: 2,
        opacity: 1,
        fillOpacity: 0.5
    };

    // Ajout des éléments à la carte
    var lieux = <?= json_encode($lieux) ?>;
    var markers = {};
    
    lieux.forEach(lieu => {
        var geojson = JSON.parse(lieu.geojson);
        var layer;
        
        switch(lieu.type_geometrie) {
            case 'ST_Point':
                layer = L.circleMarker([lieu.lat, lieu.lon], pointStyle)
                    .bindPopup(`<b>${lieu.nom}</b><br>Type: Point`);
                pointLayer.addLayer(layer);
                break;
            case 'ST_LineString':
                layer = L.geoJSON(geojson, {
                    style: lineStyle
                }).bindPopup(`<b>${lieu.nom}</b><br>Type: Ligne`);
                lineLayer.addLayer(layer);
                break;
            case 'ST_Polygon':
                layer = L.geoJSON(geojson, {
                    style: polygonStyle
                }).bindPopup(`<b>${lieu.nom}</b><br>Type: Polygone`);
                polygonLayer.addLayer(layer);
                break;
        }
        
        markers[lieu.id] = layer;
    });

    // Légende
    var legend = L.control({position: 'bottomright'});
    legend.onAdd = function(map) {
        var div = L.DomUtil.create('div', 'legend');
        div.innerHTML = `
            <h6>Légende</h6>
            <div><i style="background: ${pointStyle.fillColor}"></i> Points</div>
            <div><i style="background: ${lineStyle.color}"></i> Lignes</div>
            <div><i style="background: ${polygonStyle.fillColor}"></i> Polygones</div>
        `;
        return div;
    };
    legend.addTo(map);
    // Au début de votre script, après la création des layers
pointLayer.addTo(map);
lineLayer.addTo(map);
polygonLayer.addTo(map);

    // Gestion des filtres
 // Gestion des filtres
document.querySelectorAll('.filter-type').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        // Décocher toutes les autres cases
        if (this.checked) {
            document.querySelectorAll('.filter-type').forEach(otherCheckbox => {
                if (otherCheckbox !== this) {
                    otherCheckbox.checked = false;
                }
            });
        }
        
        // Gérer l'affichage des couches
        var pointChecked = document.getElementById('filter-point').checked;
        var lineChecked = document.getElementById('filter-line').checked;
        var polygonChecked = document.getElementById('filter-polygon').checked;
        
        // Si aucune case n'est cochée, tout afficher
        if (!pointChecked && !lineChecked && !polygonChecked) {
            pointLayer.addTo(map);
            lineLayer.addTo(map);
            polygonLayer.addTo(map);
        } else {
            // Sinon afficher seulement les couches cochées
            pointChecked ? pointLayer.addTo(map) : pointLayer.remove();
            lineChecked ? lineLayer.addTo(map) : lineLayer.remove();
            polygonChecked ? polygonLayer.addTo(map) : polygonLayer.remove();
        }
    });
});

    // Gestion de la sélection dans le menu déroulant
    document.getElementById('location-select').addEventListener('change', function() {
        var selectedOption = this.options[this.selectedIndex];
        var lat = selectedOption.getAttribute('data-lat');
        var lon = selectedOption.getAttribute('data-lon');
        var type = selectedOption.getAttribute('data-type');
        
        if (lat && lon) {
            map.setView([lat, lon], 15);
            
            // Surligner l'élément sélectionné
            var id = selectedOption.value;
            if (markers[id]) {
                if (type === 'ST_Point') {
                    markers[id].setStyle({color: '#ff0000', fillColor: '#ff0000'});
                    setTimeout(() => {
                        markers[id].setStyle(pointStyle);
                    }, 2000);
                } else if (type === 'ST_LineString') {
                    markers[id].setStyle({color: '#ff0000'});
                    setTimeout(() => {
                        markers[id].setStyle(lineStyle);
                    }, 2000);
                } else if (type === 'ST_Polygon') {
                    markers[id].setStyle({color: '#ff0000', fillColor: '#ff0000'});
                    setTimeout(() => {
                        markers[id].setStyle(polygonStyle);
                    }, 2000);
                }
                markers[id].openPopup();
            }
        }
    });
    
    // Réinitialisation de la carte
    document.getElementById('reset-map').addEventListener('click', function() {
        map.setView([12.3710, -1.5195], 13);
        // Désélectionner l'élément dans le select
        document.getElementById('location-select').selectedIndex = 0;
        
        // Réinitialiser les styles des marqueurs
        Object.values(markers).forEach(marker => {
            if (marker instanceof L.CircleMarker) {
                marker.setStyle(pointStyle);
            } else if (marker instanceof L.Polyline) {
                marker.setStyle(lineStyle);
            } else if (marker instanceof L.Polygon) {
                marker.setStyle(polygonStyle);
            }
        });
    });

    // Filtrage du tableau
    document.querySelectorAll('.filter-type').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            var type = this.value.replace('ST_', '');
            var rows = document.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                var rowType = row.getAttribute('data-type');
                if (this.checked) {
                    if (rowType === this.value) {
                        row.style.display = '';
                    }
                } else {
                    if (rowType === this.value) {
                        row.style.display = 'none';
                    }
                }
            });
        });
    });
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>