<?php
include('includes/db.php');
include('includes/header.php');

$conn = connectDB();
$sort = $_POST['sort'] ?? 'asc';

$query = "SELECT id, nom, ST_GeometryType(geom) AS type_geometrie, 
             ST_X(ST_Centroid(geom)) AS lon, 
             ST_Y(ST_Centroid(geom)) AS lat,
             ST_AsGeoJSON(geom) AS geojson
             FROM lieux 
             ORDER BY nom $sort";
$result = pg_query($conn, $query) or die("Erreur lors de la requête : " . pg_last_error());
$lieux = pg_fetch_all($result) ?: [];
pg_close($conn);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Carte des Lieux du Burkina Faso</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />

    <style>
        #map { width: 100%; height: 600px; }
        .legend {
            background: white;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            font-size: 14px;
        }
        .legend i {
            width: 18px;
            height: 18px;
            float: left;
            margin-right: 8px;
            opacity: 0.7;
        }
        .point-control-panel {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .point-control-panel h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        #save-status {
            min-height: 20px;
        }
                #edit-btn.active {
            background-color: #dc3545;
            border-color: #dc3545;
        }

        #save-geometry-btn:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        #edit-geometry-btn {
    background-color: #4CAF50;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    margin-top: 10px;
}

#edit-geometry-btn:hover {
    background-color: #45a049;
}
#custom-toolbar {
    position: absolute;
    top: 100px;
    left: 10px;
    z-index: 1000;
    background: white;
    padding: 10px;
    border-radius: 6px;
    box-shadow: 0 0 6px rgba(0,0,0,0.2);
}

#radius-select-btn {
    background-color: white;
    border: 1px solid #ccc;
    color: black;
    padding: 6px 10px;
    font-size: 14px;
    cursor: pointer;
    border-radius: 4px;
}

#radius-select-btn.active {
    background-color: #4CAF50;
    color: white;
}
#radius-input-container {
    position: absolute;
    top: 160px; /* en dessous du bouton */
    left: 10px;
    z-index: 1000;
    background: white;
    padding: 10px;
    border-radius: 6px;
    box-shadow: 0 0 6px rgba(0,0,0,0.2);
    width: 180px;
}
#radius-result-list {
    position: absolute;
    top: 280px; /* ajuste selon ta mise en page */
    left: 10px;
    z-index: 1000;
    background-color: white;
    padding: 10px 15px;
    border-radius: 6px;
    box-shadow: 0 0 8px rgba(0,0,0,0.15);
    font-size: 13px;
    max-width: 180px;
    line-height: 1.4;
}

#radius-result-list ul {
    list-style-type: disc;
    padding-left: 20px;
    margin: 5px 0 0 0;
}

#radius-result-list li {
    margin: 3px 0;
}
    </style>
</head>

<body>
<div class="container mt-4">
    <h1 class="mb-4">Carte des Lieux du Burkina Faso</h1>

    <!-- Carte et filtres -->
    <div class="row mb-4">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Carte interactive</div>
                <div class="card-body p-0">
                    <?php include('views/index/map.php'); ?>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <?php include('views/index/controls.php'); ?>
        </div>
    </div>

 <div id="custom-toolbar">
    <button id="radius-select-btn" title="Sélection par rayon">⦿ Sélection par rayon</button>
</div>

<div id="radius-input-container" style="display:none; margin-top: 10px;">
    <label for="radius-input">Rayon (m) :</label><br>
    <input type="number" id="radius-input" min="1" placeholder="Ex: 50" style="width: 150px; margin-top: 5px;"><br>
    <button id="radius-validate-btn" style="margin-top: 5px;">Valider</button>
</div>

<!-- ✅ Résultat séparé -->
<div id="radius-result-list" style="display:none; margin-top: 10px; padding: 10px; background: white; border-radius: 6px; box-shadow: 0 0 6px rgba(0,0,0,0.1); font-size: 13px;"></div>

    <!-- Panneau de modification  -->
  
<div class="feature-control-panel">
    <h3 class="mb-3">Modifier un élément existant</h3>

    <!-- Sélection de l'élément -->
    <div class="mb-3">
        <label for="feature-select" class="form-label">Élément à modifier :</label>
        <select id="feature-select" class="form-select">
            <option value="">-- Veuillez sélectionner --</option>
        </select>
    </div>

    <!-- Saisie du nouveau nom -->
    <div class="mb-3">
        <label for="feature-name" class="form-label">Nom de l'élément :</label>
        <input type="text" id="feature-name" class="form-control" placeholder="Entrez le nouveau nom" disabled>
    </div>

    <!-- Coordonnées pour les points -->
    <div class="mb-3" id="point-coords-container" style="display: none;">
        <label class="form-label">Coordonnées du point :</label>
        <div id="point-coords" class="form-control bg-light text-muted">Non sélectionné</div>
    </div>
    
    <button id="edit-geometry-btn" class="btn btn-warning mt-2" style="display:none;">
        <i class="fas fa-edit"></i> Modifier la forme
    </button>
    
   

    <!-- Bouton de sauvegarde -->
    <button id="save-feature-btn" class="btn btn-success w-100" disabled>
        <i class="fa fa-save me-2"></i>Enregistrer les modifications
    </button>

    <!-- Message de statut -->
    <div id="save-status" class="mt-3 text-center text-info"></div>
</div>



    <!-- Formulaire d'ajout de point -->
    <div class="card mb-4">
        <div class="card-header">Ajouter un nouveau point</div>
        <div class="card-body">
            <?php include('views/index/form.php'); ?>
        </div>
    </div>

    <!-- Tableau des lieux -->
    <div class="card">
        <div class="card-header">Liste des lieux</div>
        <div class="card-body">
            <?php include('views/index/table.php'); ?>
        </div>
    </div>
</div>

<script>
window.lieuxData = <?= json_encode($lieux) ?>;

</script>
<script src="https://unpkg.com/leaflet/dist/leaflet.js">
   

</script>
<script src="https://unpkg.com/leaflet-editable@1.2.0/src/Leaflet.Editable.js"></script>
<!-- À la fin du body -->
<script src="https://cdn.jsdelivr.net/npm/@turf/turf@6/turf.min.js"></script>

<script src="js/map.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
