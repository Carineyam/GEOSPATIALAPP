<?php
header('Content-Type: application/json');
include('../includes/db.php');

$response = ['success' => false, 'message' => ''];

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Méthode non autorisée', 405);
    }

    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $geojson = $_POST['geojson'] ?? '';
    
    if (!$id || !$geojson) {
        throw new Exception('Données manquantes', 400);
    }

    $conn = connectDB();
    if (!$conn) {
        throw new Exception('Connexion DB impossible');
    }

    // Convertir GeoJSON en WKT pour PostGIS
    $geom = json_decode($geojson, true);
    if (!$geom) {
        throw new Exception('GeoJSON invalide');
    }

    $wkt = '';
    if ($geom['type'] === 'LineString') {
        $coords = array_map(function($c) {
            return implode(' ', $c);
        }, $geom['coordinates'][0]);
        $wkt = 'LINESTRING(' . implode(',', $coords) . ')';
    } elseif ($geom['type'] === 'Polygon') {
        $rings = [];
        foreach ($geom['coordinates'] as $ring) {
            $coords = array_map(function($c) {
                return implode(' ', $c);
            }, $ring);
            $rings[] = '(' . implode(',', $coords) . ')';
        }
        $wkt = 'POLYGON(' . implode(',', $rings) . ')';
    } else {
        throw new Exception('Type de géométrie non supporté');
    }

    $query = "UPDATE lieux SET geojson = $1, geom = ST_GeomFromText($2, 4326) WHERE id = $3";
    $result = pg_query_params($conn, $query, [$geojson, $wkt, $id]);

    if (!$result) {
        throw new Exception(pg_last_error($conn));
    }

    $response['success'] = true;
    $response['message'] = 'Géométrie mise à jour';

} catch (Exception $e) {
    http_response_code($e->getCode() ?: 500);
    $response['message'] = $e->getMessage();
} finally {
    if (isset($conn)) pg_close($conn);
}

echo json_encode($response);